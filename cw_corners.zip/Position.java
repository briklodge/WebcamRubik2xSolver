package gameAI.rubiks;

public class Position 
{
	// fixed slots, describe content
	private int[] pla; // val 0-7
	private int[] ori; // val 0-2
	private long pack = -1;
	
	private static int[] plaxyz = new int[]{0,1,3,2,6,7,5,4};
	private static int[] xyzpla = new int[]{0,1,3,2,7,6,4,5};
	
	//pla xyz 000 001 011 010 110 111 101 100 

	//ori (x=0) 0 = (xcol = xdir), 1 = ccw, 2 = cw
	
	
	//fac 0 = x0, 1 = y0, 2 = z0, 3 = x1, 4 = y1, 5 = z1
	
	public Position()
	{
		pla = new int[]{0,1,2,3,4,5,6,7};
		ori = new int[]{0,0,0,0,0,0,0,0};
	}
	
	public Position(int[] pla, int[] ori)
	{
		this.pla = pla;
		this.ori = ori;
	}
	
	public static int place(int x, int y, int z)
	{
		return xyzpla[(x<<2)|(y<<1)|(z)];
	}
	
	public long pack()
	{
		if(pack == -1)
		{
			pack = 0;
			for(int i=0;i<8;i++)
				pack=(pack<<5)|(pla[i]<<2)|(ori[i]);
		}
		return pack;
	}
	
	public void unpack(long pack)
	{
		for(int i=7;i>=0;i--)
		{
			ori[i] = (int)(pack&3);
			pack >>= 2;
			pla[i] = (int)(pack&7);
			pack >>= 3;
		}
	}
	
	public void print(char x0,char y0,char z0,char x1,char y1,char z1)
	{
		char[][] map = new char[][]{
				{x0,y0,z0,x0,y0,z0},
				{x0,z1,y0,x0,z1,y0},
				{x0,y1,z1,x0,y1,z1},
				{x0,z0,y1,x0,z0,y1},
				{x1,y1,z0,x1,y1,z0},
				{x1,z1,y1,x1,z1,y1},
				{x1,y0,z1,x1,y0,z1},
				{x1,z0,y0,x1,z0,y0},
		};

		for(int i=0;i<8;i++)
			System.out.println(pla[i]+" "+ori[i]);
		
		System.out.printf("    %s %s\n", map[pla[2]][ori[2]+2], map[pla[5]][ori[5]+1]);
		System.out.printf("    %s %s\n", map[pla[1]][ori[1]+1], map[pla[6]][ori[6]+2]);
		System.out.printf("%s %s %s %s %s %s\n",
				map[pla[2]][ori[2]], map[pla[1]][ori[1]],
				map[pla[1]][ori[1]+2], map[pla[6]][ori[6]+1],
				map[pla[6]][ori[6]], map[pla[5]][ori[5]]);
		System.out.printf("%s %s %s %s %s %s\n",
				map[pla[3]][ori[3]], map[pla[0]][ori[0]],
				map[pla[0]][ori[0]+1], map[pla[7]][ori[7]+2],
				map[pla[7]][ori[7]], map[pla[4]][ori[4]]);
		System.out.printf("    %s %s\n", map[pla[0]][ori[0]+2], map[pla[7]][ori[7]+1]);
		System.out.printf("    %s %s\n", map[pla[3]][ori[3]+1], map[pla[4]][ori[4]+2]);
		
	}
	
	//pla xyz 000 001 011 010 110 111 101 100 
	//ori 0 = (wh/ye = x), 1 = (wh/ye = y), 2 = (wh/ye = z)
	//fac 0 = x0, 1 = y0, 2 = z0, 3 = x1, 4 = y1, 5 = z1

	public void cw(int face)
	{
		pack = -1;
		int[][] affected = new int[][]{
				{0,1,2,3},
				{7,6,1,0},
				{0,3,4,7},
				{4,5,6,7},
				{5,4,3,2},
				{6,5,2,1}
		};
		int[][] rot = new int[][]{
				{0,2,1},
				{2,1,0},
				{1,0,2},
				{0,2,1},
				{2,1,0},
				{1,0,2}
		};
		
		int tmp = pla[affected[face][0]];
		pla[affected[face][0]] = pla[affected[face][1]];
		pla[affected[face][1]] = pla[affected[face][2]];
		pla[affected[face][2]] = pla[affected[face][3]];
		pla[affected[face][3]] = tmp;
		
		tmp = rot[face][ori[affected[face][0]]];
		ori[affected[face][0]] = rot[face][ori[affected[face][1]]];
		ori[affected[face][1]] = rot[face][ori[affected[face][2]]];
		ori[affected[face][2]] = rot[face][ori[affected[face][3]]];
		ori[affected[face][3]] = tmp;
	}
	public void ccw(int face)
	{
		pack = -1;
		int[][] affected = new int[][]{
				{0,1,2,3},
				{7,6,1,0},
				{0,3,4,7},
				{4,5,6,7},
				{5,4,3,2},
				{6,5,2,1}
		};
		int[][] rot = new int[][]{
				{0,2,1},
				{2,1,0},
				{1,0,2},
				{0,2,1},
				{2,1,0},
				{1,0,2}
		};
		
		int tmp = pla[affected[face][3]];
		pla[affected[face][3]] = pla[affected[face][2]];
		pla[affected[face][2]] = pla[affected[face][1]];
		pla[affected[face][1]] = pla[affected[face][0]];
		pla[affected[face][0]] = tmp;
		
		tmp = rot[face][ori[affected[face][3]]];
		ori[affected[face][3]] = rot[face][ori[affected[face][2]]];
		ori[affected[face][2]] = rot[face][ori[affected[face][1]]];
		ori[affected[face][1]] = rot[face][ori[affected[face][0]]];
		ori[affected[face][0]] = tmp;
	}
}
